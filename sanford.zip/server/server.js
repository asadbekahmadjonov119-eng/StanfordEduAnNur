// import express from "express";
// import mongoose from "mongoose";
// import cors from "cors";

// const app = express();
// app.use(cors());
// app.use(express.json());
// app.use(express.static("../"));


// // MongoDB ulanishi
// mongoose
//   .connect("mongodb+srv://stanford_admin:Asadbek123@cluster0.ip7nrof.mongodb.net/stanford")
//   .then(() => console.log("✅ MongoDB ulandi"))
//   .catch((err) => console.log("❌ MongoDB xato:", err));

// // Model (schema)
// const studentSchema = new mongoose.Schema({
//   name: String,
//   group: String,
//   paid: Boolean
// });
// const Student = mongoose.model("Student", studentSchema);

// // 🔹 O‘quvchini qo‘shish (POST)
// app.post("/api/students", async (req, res) => {
//   try {
//     const student = new Student(req.body);
//     await student.save();
//     res.json({ message: "✅ O‘quvchi qo‘shildi", student });
//   } catch (err) {
//     res.status(500).json({ error: "Server xatosi" });
//   }
// });

// // 🔹 Barcha o‘quvchilarni olish (GET)
// app.get("/api/students", async (req, res) => {
//   try {
//     const students = await Student.find();
//     res.json(students);
//   } catch (err) {
//     res.status(500).json({ error: "Server xatosi" });
//   }
// });

// // Serverni ishga tushirish
// app.listen(5000, () => console.log("🚀 Server 5000-portda ishlamoqda"));



import express from "express";
import mongoose from "mongoose";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const uri = "mongodb+srv://stanford_admin:Asadbek123@cluster0.ip7nrof.mongodb.net/stanford";

mongoose.connect(uri)
  .then(() => console.log("✅ MongoDB ulandi"))
  .catch((err) => console.error("❌ MongoDB xato:", err));

app.get("/", (req, res) => {
  res.send("Server ishlayapti 🚀");
});

const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server ${PORT}-portda ishlamoqda`));

